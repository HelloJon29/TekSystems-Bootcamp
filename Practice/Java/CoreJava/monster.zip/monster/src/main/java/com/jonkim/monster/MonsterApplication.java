package com.jonkim.monster;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MonsterApplication {

	public static void main(String[] args) {
		SpringApplication.run(MonsterApplication.class, args);
	}

}
