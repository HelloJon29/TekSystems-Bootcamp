package com.jonkim.managerandtrainee;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ManagerandtraineeApplicationTests {

	@Test
	void contextLoads() {
	}

}
