package com.jonkim.managerandtrainee;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ManagerandtraineeApplication {

	public static void main(String[] args) {
		SpringApplication.run(ManagerandtraineeApplication.class, args);
	}

}
